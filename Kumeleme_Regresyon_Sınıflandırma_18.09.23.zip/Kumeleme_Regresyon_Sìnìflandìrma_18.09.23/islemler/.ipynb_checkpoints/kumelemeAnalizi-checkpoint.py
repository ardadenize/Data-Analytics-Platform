import streamlit as st
import pandas as pd 
from pandas_profiling import ProfileReport
from streamlit_pandas_profiling import st_profile_report
from dateutil import parser


def kumeleme_analizi(uploaded_file):
     st.write("Kümeleme Analizi işlemleri")
     df = pd.read_csv(uploaded_file)


def kumeleme_analizi_sonuclar():
        tab1, tab2, tab3 = st.tabs(["CSV", "XLSX", "TXT"])

        with tab1:
            uploaded_file_csv = st.file_uploader("Lütfen bir veri seti seçin (CSV)", type="csv")
            if uploaded_file_csv is not None:
                kumeleme_analizi(uploaded_file_csv)
            else:
                st.write('Lütfen veri yükleyin...')
                

        with tab2:
            uploaded_file_xlsx = st.file_uploader("Lütfen bir veri seti seçin (XLSX)", type="xlsx")
            if uploaded_file_csv is not None:
                kumeleme_analizi(uploaded_file_csv)
            else:
                st.write('Lütfen veri yükleyin...')

        with tab3:
            uploaded_file = st.file_uploader("Lütfen bir veri seti seçin (TXT)", type="txt")
            if uploaded_file_csv is not None:
                kumeleme_analizi(uploaded_file_csv)
            else:
                st.write('Lütfen veri yükleyin...')
 